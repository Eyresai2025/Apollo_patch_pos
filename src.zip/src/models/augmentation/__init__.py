"""Apollo patch augmentation package."""
